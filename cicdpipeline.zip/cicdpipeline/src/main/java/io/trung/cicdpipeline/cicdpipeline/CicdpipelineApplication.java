package io.trung.cicdpipeline.cicdpipeline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CicdpipelineApplication {

	public static void main(String[] args) {
		SpringApplication.run(CicdpipelineApplication.class, args);
	}

}
